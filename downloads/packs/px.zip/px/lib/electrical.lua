-- Shared target queries, the Tazer's arc and beam rendering for the electrical weapons.

local electrical = {}
local context, installed

local providers, order = {}, {}
function electrical.register(provider)
  if not providers[provider.kind] then order[#order + 1] = provider.kind end
  providers[provider.kind] = provider
end

function electrical.special_targets()
  local out = {}
  for _, kind in ipairs(order) do
    local provider = providers[kind]
    for _, obj in ipairs(provider.targets()) do
      obj.kind, obj.provider = kind, provider
      out[#out + 1] = obj
    end
  end
  return out
end

function electrical.special(key)
  local kind, id = key:match("^([^:]+):(.+)$")
  if not (kind and providers[kind]) then return nil end
  for _, obj in ipairs(providers[kind].targets()) do
    if tostring(obj.id) == id then
      obj.kind, obj.provider = kind, providers[kind]
      return obj
    end
  end
end

function electrical.special_on_beam(x0, y0, dx, dy, length)
  local best, hit
  for _, obj in ipairs(electrical.special_targets()) do
    local cx, cy = obj.x - x0, obj.y - y0
    local along = cx * dx + cy * dy
    local miss = cx * cx + cy * cy - along * along
    local r = obj.radius or 9
    if miss <= r * r then
      local at = along - math.sqrt(math.max(0, r * r - miss))
      if at > 0 and at < length and (not best or at < best) then best, hit = at, obj end
    end
  end
  if best then return x0 + best * dx, y0 + best * dy, hit end
end
function electrical.context()
  if context then return context end
  local function sq(v) return v * v end
  local shared = require("lib/shared")
  local ELECTRIC_DEPTH = wa.depth.BEHIND_TERRAIN
  local BEAM = "sprites/lightning/beam.png"
  local GLOW = "sprites/lightning/glow.png"
  local CLOUD = "sprites/lightning/cloud.png"
  local CLOUD_DEPTH = ELECTRIC_DEPTH - 0x1000
  local GRENADE_BURST = "sprites/electric_grenade/explosion.png"
  local strikes, arcs, tazed = {}, {}, {}
  shared.revived_by_lightning = shared.revived_by_lightning or {}
  local function effect_actor(x, y, owner, frame)
    return wa.actors.spawn({
      sprite = GLOW, visible = false, gravity = false, collide = false,
      owner = owner, x = x, y = y, on = frame,
    })
  end

  local function electrical_targets(graves)
    local out = {}
    for _, group in ipairs({ wa.worms, wa.mines, wa.crates, wa.oil }) do
      for _, obj in ipairs(group.all()) do out[#out + 1] = obj end
    end
    if graves and wa.graves then
      for _, obj in ipairs(wa.graves.all()) do out[#out + 1] = obj end
    end
    return out
  end

  local function target_radius(obj)
    if obj.radius then return obj.radius end
    if obj.kind == "worm" then return 6 end
    if obj.kind == "grave" then return 8 end
    if obj.kind == "mine" then return 5 end
    return 9
  end

  local function electrical_trace(x0, y0, dx, dy)
    local far = 10000
    if wa.world.electrical_trace then
      return wa.world.electrical_trace(x0, y0,
        (x0 + dx * far), (y0 + dy * far))
    end
    local land = wa.land.trace(x0, y0,
      (x0 + dx * far), (y0 + dy * far))
    local best = land and math.sqrt(sq(land.x - x0) + sq(land.y - y0)) or far
    local hit = land and { x = land.x, y = land.y, obj = nil } or nil
    for _, obj in ipairs(electrical_targets(true)) do
      local ox, oy = (obj.x - x0), (obj.y - y0)
      local along = ox * dx + oy * dy
      local across = math.abs(ox * dy - oy * dx)
      if along > 0 and along < best and across <= target_radius(obj) then
        best = along
        hit = { x = obj.x, y = obj.y, obj = obj }
      end
    end
    return hit
  end
  local function target_key(obj)
    return obj.kind .. ":" .. obj.id
  end

  local function find_target(key)
    local ball = key:match("^ball:(%d+)$")
    if ball then
      return shared.bowling_ball_target and shared.bowling_ball_target(tonumber(ball))
    end
    local special = electrical.special(key)
    if special then return special end
    for _, obj in ipairs(electrical_targets(false)) do
      if target_key(obj) == key then return obj end
    end
  end

  local function closest_target(arc)
    local best, distance = nil, sq(200)
    local targets = wa.world.electrical_nearby
      and wa.world.electrical_nearby(arc.x, arc.y, 200, false) or electrical_targets(false)
    local function consider(obj)
      local key = target_key(obj)
      if not arc.ignore[key] and (obj.kind ~= "worm" or obj.hp > 0) then
        local dx, dy = obj.x - arc.x, obj.y - arc.y
        local d = dx * dx + dy * dy
        if d < distance then best, distance = obj, d end
      end
    end
    for _, obj in ipairs(targets) do consider(obj) end
    if shared.bowling_ball_targets then
      for _, obj in ipairs(shared.bowling_ball_targets()) do consider(obj) end
    end
    for _, obj in ipairs(electrical.special_targets()) do consider(obj) end
    return best, distance
  end

  local function release_taze(key)
    local hold = tazed[key]
    if not hold then return end
    hold.count = hold.count - 1
    if hold.count > 0 then return end
    local worm = hold.worm
    if worm.taken then worm:release(0, 0) end
    worm.body_visible = true
    tazed[key] = nil
  end

  local function zap_target(arc, pending)
    local obj = find_target(pending.key)
    release_taze(pending.key)
    if not obj then return end
    if obj.kind == "worm" then
      obj:hurt({ amount = 24, kind = "taze" })
      obj.vx, obj.vy = pending.side * 1.2, -4
    elseif obj.kind == "mine" then
      obj:arm(400)
    elseif obj.kind == "crate" or obj.kind == "oil" then
      obj:hit(12, pending.side * 1.2, -4, "taze")
    elseif obj.kind == "ball" then
      shared.zap_bowling_ball(obj.id)
    elseif obj.provider then
      obj.provider.zap(obj, pending.side)
    end
  end

  local ARC_MAX_POINTS = 256
  local function add_point(arc)
    arc.points[#arc.points + 1] = { arc.x, arc.y }
    if #arc.points > ARC_MAX_POINTS then table.remove(arc.points, 1) end
  end

  local LINK_DISTANCE = 10 / 0.81

  local function progress_arc(arc)
    arc.explosion = arc.explosion + 1
    for i = #arc.pending, 1, -1 do
      local p = arc.pending[i]
      p.time = p.time - 1
      if p.time <= 0 then
        zap_target(arc, p)
        table.remove(arc.pending, i)
      end
    end
    if arc.pause > 0 then arc.pause = arc.pause - 1; return end
    if arc.life <= 0 then
      if #arc.points > 0 then table.remove(arc.points, 1) end
      return
    end
    arc.life = arc.life - 1
    local target, distance = closest_target(arc)
    if target then
      local dx, dy = target.x - arc.x, target.y - arc.y
      local d = math.sqrt(distance)
      if d <= LINK_DISTANCE then
        local key = target_key(target)
        arc.ignore[key] = true
        arc.pending[#arc.pending + 1] = { key = key, side = dx < 0 and -1 or 1, time = 24 }
        if target.kind == "worm" then
          if tazed[key] then
            tazed[key].count = tazed[key].count + 1
          else
            tazed[key] = { x = target.x, y = target.y, count = 1, worm = target,
              sheet = wa.random(1, 2) == 1 and "sprites/electric_grenade/tazed1.png" or "sprites/electric_grenade/tazed2.png" }
          end
          target.body_visible = false
          target:take{ turn = "freeze" }
        end
        arc.x, arc.y = target.x, target.y
        arc.life = 20
        arc.pause = 14
        add_point(arc)
        return
      end
      local pull = math.min(1, math.sqrt(10 / d))
      arc.dx = arc.dx + ((dx / d) - arc.dx) * pull
      arc.dy = arc.dy + ((dy / d) - arc.dy) * pull
    else
      arc.dx = arc.dx + wa.random(-100, 100) / 100
      arc.dy = arc.dy + wa.random(-100, 100) / 100
    end
    local norm = math.sqrt(arc.dx * arc.dx + arc.dy * arc.dy)
    if norm < 0.01 then arc.dx, arc.dy = 0, -1 else arc.dx, arc.dy = arc.dx / norm, arc.dy / norm end
    local nx, ny = arc.x + arc.dx * 20, arc.y + arc.dy * 20
    local land = wa.land.trace(arc.x, arc.y, nx, ny)
    if land then
      if land.starts_solid then arc.life = 0; return end
      local tx, ty = land.tx or 1, land.ty or 0
      if target then
        local a = sq(target.x - (land.x + tx * 10)) + sq(target.y - (land.y + ty * 10))
        local b = sq(target.x - (land.x - tx * 10)) + sq(target.y - (land.y - ty * 10))
        if b < a then tx, ty = -tx, -ty end
      end
      arc.dx, arc.dy = tx, ty
      arc.x, arc.y = land.x + (land.nx or 0) * 10 + tx * 10,
        land.y + (land.ny or -1) * 10 + ty * 10
    else
      arc.x, arc.y = arc.x + arc.dx * 10, arc.y + arc.dy * 10
    end
    add_point(arc)
  end

  local function start_arc(ev)
    local arc = { x = ev.x, y = ev.y, dx = ev.dx or 0, dy = ev.dy or -1, life = ev.life or 16, pause = 0,
      points = { { ev.x, ev.y } }, ignore = {}, pending = {}, explosion = 0,
      burst_x = ev.x, burst_y = ev.y, sound_age = 0, burst = ev.burst ~= false }
    for _,obj in ipairs(ev.ignore or {}) do arc.ignore[target_key(obj)] = true end
    arcs[#arcs + 1] = arc
    local driver = effect_actor(ev.x, ev.y, ev.worm or shared.current_worm() or ev.owner, function(a)
      arc.sound_age = arc.sound_age + 1
      if arc.life > 0 and arc.sound_age % 46 == 0 then
        wa.sound.play(a, "sounds/lightning/tazer_loop.wav")
      end
      progress_arc(arc)
      if arc.life <= 0 and #arc.points == 0 and #arc.pending == 0 then
        for i, held in ipairs(arcs) do
          if held == arc then table.remove(arcs, i); break end
        end
        a:despawn()
      end
    end)
    wa.sound.play(driver, "sounds/lightning/tazer_loop.wav")
  end

  local function grenade_arc(ev)
    local ignore = {}
    if context.thrower then ignore[#ignore+1] = context.thrower end
    if ev.worm then ignore[#ignore+1] = ev.worm end
    return start_arc({x=ev.x,y=ev.y,worm=ev.worm,owner=ev.owner,life=ev.life,ignore=ignore})
  end

  context = { sq = sq, ELECTRIC_DEPTH = ELECTRIC_DEPTH, BEAM = BEAM, GLOW = GLOW, CLOUD = CLOUD, CLOUD_DEPTH = CLOUD_DEPTH, GRENADE_BURST = GRENADE_BURST, strikes = strikes, arcs = arcs, tazed = tazed, effect_actor = effect_actor, electrical_targets = electrical_targets, target_radius = target_radius, electrical_trace = electrical_trace, target_key = target_key, find_target = find_target, start_arc = start_arc, grenade_arc = grenade_arc }
  return context
end

function electrical.setup()
  if installed then return end
  installed = true
  local c = electrical.context()
  local sq = c.sq
  local ELECTRIC_DEPTH = c.ELECTRIC_DEPTH
  local BEAM = c.BEAM
  local GLOW = c.GLOW
  local CLOUD = c.CLOUD
  local CLOUD_DEPTH = c.CLOUD_DEPTH
  local GRENADE_BURST = c.GRENADE_BURST
  local strikes = c.strikes
  local arcs = c.arcs
  local tazed = c.tazed
  local effect_actor = c.effect_actor
  local electrical_targets = c.electrical_targets
  local target_radius = c.target_radius
  local electrical_trace = c.electrical_trace
  local find_target = c.find_target
  wa.on.worm_message(function(worm, msg)
    if tazed[c.target_key(worm)] then return "eat" end
  end, { msgs = { wa.msg.FIRE_WEAPON } })
  if wa.on.draw and wa.draw.ribbon then
    local beam_sprite = wa.sprites.key(BEAM)
    local glow_sprite = wa.sprites.key(GLOW)
    local cloud_sprite = wa.sprites.key(CLOUD)
    local burst_sprite = wa.sprites.key(GRENADE_BURST)
    local function colour(a, r, g, b)
      return (math.floor(a) << 24) | (r << 16) | (g << 8) | b
    end
    local QUAD = { points = { {0, 0}, {0, 0}, {0, 0}, {0, 0} } }
    local function square(sprite, frame, blend, color, depth, x, y, hw, hh)
      QUAD.sprite, QUAD.frame, QUAD.blend, QUAD.color, QUAD.depth = sprite, frame, blend, color, depth
      local p = QUAD.points
      p[1][1], p[1][2] = x - hw, y - hh
      p[2][1], p[2][2] = x + hw, y - hh
      p[3][1], p[3][2] = x + hw, y + hh
      p[4][1], p[4][2] = x - hw, y + hh
      wa.draw.quad(QUAD)
    end
    local function glow(x, y, size, color)
      local h = size / 2
      square(glow_sprite, 0, "add", color, ELECTRIC_DEPTH, x, y, h, h)
    end
    local RIBBON = { sprite = beam_sprite, blend = "add", depth = ELECTRIC_DEPTH, points = {} }
    local POINTS = {}
    local function point(i, x, y, width, u, color)
      local p = POINTS[i]
      if not p then p = {}; POINTS[i] = p end
      RIBBON.points[i] = p
      p.x, p.y, p.width, p.u, p.color = x, y, width, u, color
    end
    local function ribbon(n)
      local pts = RIBBON.points
      for i = #pts, n + 1, -1 do pts[i] = nil end
      wa.draw.ribbon(RIBBON)
    end
    local LR, LG, LB = 120, 140, 255
    local function lerp(t, a, b) return a + (b - a) * t end
    local function noise_span(noise, off, divs, scale, first, last)
      for i = 0, divs - 1 do noise[off + i] = 0 end
      noise[off], noise[off + divs - 1] = first, last
      local k = divs
      local l = k >> 1
      while l > 0 do
        for i = l, divs - 1 - l, k do
          noise[off + i] = (noise[off + i - l] + noise[off + i + l]) * 0.5 + (wa.draw.random() * 2 - 1) * scale
        end
        k = l
        l = k >> 1
      end
    end
    local function new_shape(s)
      s.noise, s.attach = s.noise or {}, s.attach or {}
      for i = 1, 8 do s.attach[i] = nil end
      noise_span(s.noise, 0, 9, 1.0, 0, 0)
      for _ = 1, 6 do s.attach[1 + math.floor(wa.draw.random() * 8)] = true end
      for i = 0, 5 do
        local off = 2 + wa.draw.random() * 4
        if wa.draw.random() < 0.5 then off = -off end
        noise_span(s.noise, 9 + 9 * i, 9, 0.5, 0, off)
      end
      s.ground = 0.5 + wa.draw.random() * 0.3
      -- Each frame of the bolt flashes anew; now and then one is weaker.
      s.flicker = wa.draw.random() < 0.25 and 0.5 or 0.85 + 0.15 * wa.draw.random()
      s.flicker_x = (wa.draw.random() * 2 - 1) * 25
      s.shape_tick = s.ticks
    end
    -- A bolt's glow: a strip through the bolt's points, cut from the middle
    -- column of the glow sheet (u 0.5), so it follows each bend smoothly.
    local HALO = { sprite = glow_sprite, blend = "add", depth = ELECTRIC_DEPTH, points = {} }
    local function beam(noise, off, divs, width, endwidth, scale, x1, y1, x2, y2, glowalpha)
      if divs < 2 then return end
      local dx, dy = (x2 - x1), (y2 - y1)
      local dd = math.sqrt(dx * dx + dy * dy)
      if dd <= 0 then return end
      dx, dy = dx / dd, dy / dd
      local d = divs - 1
      local halo = HALO.points
      -- Wider than two sections, the strip would fold over itself at a bend.
      local reach = math.min(64, 2 * dd / d)
      for i = #halo, divs + 1, -1 do halo[i] = nil end
      for i = 0, divs - 1 do
        local f = i / d
        local n = noise[off + i] or 0
        local x = lerp(f, x1, x2) + scale * dy * n
        local y = lerp(f, y1, y2) - scale * dx * n
        point(i + 1, x, y, 2 * lerp(f, width, endwidth), f, colour(255, LR, LG, LB))
        local h = halo[i + 1] or {}
        halo[i + 1] = h
        -- A branch's glow starts from nothing where it leaves the bolt.
        local start = (glowalpha < 1 and i == 0) and 0 or 1
        h.x, h.y, h.width, h.u = x, y, reach * (1 - 0.75 * (1 - start)), 0.5
        h.color = colour(255 * glowalpha * (1 - f) * start, LR, LG, LB)
      end
      ribbon(divs)
      wa.draw.ribbon(HALO)
    end
    -- The cloud. Each puff is drawn dark, and while a light is on in the
    -- cloud it is drawn again over itself, lit corner by corner: white near
    -- the light, deep blue further off. Near the light it is added on once
    -- more, so the cloud glows there. Light going up falls off faster,
    -- because the cloud stands between the light and the sky. With `spread`
    -- 1 each corner is lit by where it is, a smooth fall across the cloud;
    -- with less, the middle of the puff counts more, so a small light stays
    -- on the puffs around it. The dark puffs and the glow take one colour a
    -- puff, so each goes in one wa.draw.quads call.
    local DARK = { sprite = cloud_sprite, frame = 0, blend = "alpha", depth = CLOUD_DEPTH, quads = {}, count = 0 }
    local GLOWS = { sprite = cloud_sprite, frame = 0, blend = "add", depth = CLOUD_DEPTH - 0x200, quads = {}, count = 0 }
    local LIT = { sprite = cloud_sprite, frame = 0, blend = "alpha", depth = CLOUD_DEPTH - 0x100,
      points = { {0, 0}, {0, 0}, {0, 0}, {0, 0} }, colors = { 0, 0, 0, 0 } }
    local function batch(b, n, pts, color)
      if not wa.draw.quads then
        QUAD.sprite, QUAD.frame, QUAD.blend, QUAD.color, QUAD.depth = b.sprite, 0, b.blend, color, b.depth
        local q = QUAD.points
        for i = 1, 4 do q[i][1], q[i][2] = pts[i][1], pts[i][2] end
        wa.draw.quad(QUAD)
        return n
      end
      local l = b.quads
      l[n + 1], l[n + 2], l[n + 3], l[n + 4] = pts[1][1], pts[1][2], pts[2][1], pts[2][2]
      l[n + 5], l[n + 6], l[n + 7], l[n + 8] = pts[3][1], pts[3][2], pts[4][1], pts[4][2]
      l[n + 9] = color
      return n + 9
    end
    local function draw_cloud(s, lx, ly, power, reach, spread)
      local pts, cols = LIT.points, LIT.colors
      local function light(x, y)
        local dx, dy = x - lx, y - ly
        if dy < 0 then dy = dy * 3 end
        return power / (1 + (dx * dx + dy * dy) / (reach * reach))
      end
      local dark, glows = 0, 0
      for _, puff in ipairs(s.cloud) do
        local t = puff.age / puff.life
        local size = lerp(t, puff.s0, puff.s1)
        local x, y, hw, hh = puff.x, puff.y, 64 * size, 40 * size
        pts[1][1], pts[1][2] = x - hw, y - hh
        pts[2][1], pts[2][2] = x + hw, y - hh
        pts[3][1], pts[3][2] = x + hw, y + hh
        pts[4][1], pts[4][2] = x - hw, y + hh
        dark = batch(DARK, dark, pts, colour(255 * t, 45, 40, 60))
        if power > 0 then
          local lit = 0
          for i = 1, 4 do
            local l = light(x + spread * (pts[i][1] - x), y + spread * (pts[i][2] - y))
            cols[i] = colour(255 * t * math.min(1, 1.5 * l), math.floor(lerp(l, 70, 235)),
              math.floor(lerp(l, 80, 240)), math.floor(lerp(l, 190, 255)))
            lit = lit | cols[i]
          end
          if lit >> 24 > 0 then
            wa.draw.quad(LIT)
            local l = light(x, y)
            if 70 * t * l * l >= 1 then glows = batch(GLOWS, glows, pts, colour(70 * t * l * l, LR, LG, LB)) end
          end
        end
      end
      if dark > 0 then DARK.count = dark // 9; wa.draw.quads(DARK) end
      if glows > 0 then GLOWS.count = glows // 9; wa.draw.quads(GLOWS) end
    end
    -- How bright the flash is, 0..1: it builds as the bolt comes down,
    -- flickers while it stands and dies away after it.
    local function flash(s)
      if s.delay >= 8 then return 0 end
      if s.delay > 0 then return 0.3 + 0.4 * (8 - s.delay) / 8 end
      if s.life > 0 then return s.flicker or 1 end
      local f = 1 - (60 - s.tail + (wa.draw.fraction and wa.draw.fraction() or 0)) / 8
      return f > 0 and 0.5 * f * f or 0
    end
    -- Before the bolt comes down, the cloud now and then lights up inside
    -- for a moment, somewhere else each time.
    local function glimmer(s)
      if s.glimmer_tick ~= s.ticks then
        s.glimmer_tick = s.ticks
        local g = s.glimmer
        if g and s.ticks >= g.till then s.glimmer, g = nil, nil end
        if g then
          g.now = g.power * (0.4 + 0.6 * wa.draw.random())
        elseif s.delay < 110 and wa.draw.random() < 0.06 then
          local power = 0.35 + 0.3 * wa.draw.random()
          s.glimmer = { x = s.sx + (wa.draw.random() * 2 - 1) * 90, y = s.sy - 5 - wa.draw.random() * 20,
            till = s.ticks + 2 + math.floor(wa.draw.random() * 4), power = power, now = power }
        end
      end
      return s.glimmer
    end
    local function draw_strike(s)
      local power = flash(s)
      if power > 0 then
        local lx, ly = s.sx + 15 * s.dirx + (s.flicker_x or 0), s.sy + 15 * s.diry
        draw_cloud(s, lx, ly, power, 70, 0.6)
        -- Light comes out under the cloud: a wide, flat glow whose top half
        -- sits behind the dark puffs.
        QUAD.sprite, QUAD.frame, QUAD.blend, QUAD.color, QUAD.depth =
          glow_sprite, 0, "add", colour(160 * power, LR, LG, LB), ELECTRIC_DEPTH
        local q = QUAD.points
        local cx, cy = lx + 20 * s.dirx, ly + 35
        q[1][1], q[1][2] = cx - 150, cy - 75
        q[2][1], q[2][2] = cx + 150, cy - 75
        q[3][1], q[3][2] = cx + 150, cy + 75
        q[4][1], q[4][2] = cx - 150, cy + 75
        wa.draw.quad(QUAD)
      else
        local g = s.delay >= 8 and glimmer(s)
        if g then draw_cloud(s, g.x, g.y, g.now, 40, 0.3) else draw_cloud(s, 0, 0, 0, 1, 1) end
      end
      for _, p in ipairs(s.sparks) do
        local t = p.age / 50
        glow(p.x, p.y, 13 * (1 - t) + 1, colour(255, LR, LG, LB))
      end
      if s.life <= 0 or s.delay >= 8 then return end
      if not s.noise or (s.delay == 0 and s.shape_tick ~= s.ticks) then new_shape(s) end
      local divs, ex, ey = 9, s.ex, s.ey
      if s.delay > 0 then
        local fr = (8 - s.delay) / 8
        divs = math.floor(9 * fr)
        ex, ey = lerp(fr, s.sx, s.ex), lerp(fr, s.sy, s.ey)
      end
      beam(s.noise, 0, divs, 35, 3, 15, s.sx, s.sy, ex, ey, 1.0)
      local sub, d = 0, divs - 1
      for i = 0, divs - 1 do
        if s.attach[i] and d > 0 then
          local f = i / d
          local x = lerp(f, s.sx, ex) + 10 * s.diry * s.noise[i]
          local y = lerp(f, s.sy, ey) - 10 * s.dirx * s.noise[i]
          beam(s.noise, 9 + 9 * sub, 9, lerp(f, 10, 1), 0.1, 15 * (1 - f), x, y,
            x + s.dirx * 100 * (1 - f), y + s.diry * 100 * (1 - f), 0.5 * (1 - f))
          sub = sub + 1
        end
      end
      if s.delay == 0 and s.hit then glow(s.ex, s.ey, 128 * s.ground, colour(255, LR, LG, LB)) end
    end
    wa.on.draw(function()
      for _, s in ipairs(strikes) do
        draw_strike(s)
      end
      for _, arc in ipairs(arcs) do
        if arc.burst ~= false and arc.explosion < 10 then
          local h = 75
          square(burst_sprite, arc.explosion, "add", 0x551E14EB, ELECTRIC_DEPTH, arc.burst_x, arc.burst_y, h, h)
        end
        if #arc.points >= 2 then
          if arc.shape_tick ~= arc.sound_age then
            local divs = 33
            while divs < #arc.points do divs = 2 * divs - 1 end
            arc.noise = arc.noise or {}
            noise_span(arc.noise, 0, divs, 1.0, 0, 0)
            arc.shape_tick = arc.sound_age
          end
          local num = #arc.points - 1
          local fade = math.min(1, arc.life / 6)
          for i = 0, num do
            local t = i / num
            local x, y = arc.points[i + 1][1], arc.points[i + 1][2]
            if i > 0 and i < num then
              local px, py = arc.points[i][1], arc.points[i][2]
              local nx, ny = (y - py), (px - x)
              local d = math.sqrt(nx * nx + ny * ny)
              if d > 0 then
                local n = 10 * (arc.noise[i - 1] or 0) / d
                x, y = x + n * nx, y + n * ny
              end
            end
            local f = math.min(1, 4 * t * (1 - t) + 0.1)
            local f2 = f * fade
            local c = colour(255, math.floor(80 * f2), math.floor(100 * f2), math.floor(255 * f2))
            point(i + 1, x, y, 2 * 9 * f, t, c)
            glow(x, y, i == num - 1 and 115 or 38, c)
          end
          ribbon(num + 1)
        end
      end
      for _, arc in ipairs(arcs) do
        for _, p in ipairs(arc.pending) do
          if p.key:sub(1, 5) == "ball:" or electrical.special(p.key) then
            local ball = find_target(p.key)
            if ball then glow(ball.x, ball.y, 128 * (0.4 + 0.3 * wa.draw.random()), colour(255, 80, 100, 255)) end
          end
        end
      end
      for key, hold in pairs(tazed) do
        local worm = find_target(key)
        if worm then
          local x, y = worm.x, worm.y
          local h = 30
          square(hold.sheet, math.floor(wa.draw.random() * 4), "alpha", 0xFFFFFFFF, ELECTRIC_DEPTH, x, y, h, h)
          glow(x, y, 128 * (0.4 + 0.3 * wa.draw.random()), colour(255, 80, 100, 255))
        end
      end
    end)
  end
end
return electrical
