-- Fire Jump: record, art and behaviour.
local weapon = {}

-- Native record settings. Edit this weapon here; imported records are review drafts.
weapon.record = {
  fire_punch = {
    damage = 45,
    knockback = 8,
  },
}

function weapon.definition()
  return require("lib/weapon").merge(weapon.record, {
    copy_from = "stock.fire_punch",
    name = "Fire Jump",
    panel_icon = "sprites/fire_jump/fire_jump_ico.png",
  })
end

function weapon.setup()
  -- Fire Jump (PX Fire_Jump_script): WA's fire punch, whose speed then follows
  -- PX's timeline, counted in frames from the punch -- up at once, forward
  -- after half a second, a little higher at one second, and from 80 frames a
  -- fall cut back to 4 pixels a frame whenever it passes 5, until 210. PX
  -- speeds are pixels per frame; WA's are 16.16. See
  -- docs/px-reverse-engineering.md.
  --
  -- PX counts from FireFinal, which WA calls only once the punch's wind-up has
  -- played, not when fire is pressed. FireFinal starts the punch at -6 pixels
  -- a frame; the worm stood still until then. So the count starts on the
  -- first frame after fire is pressed that the worm is rising.
  --
  -- WA keeps the worm in its punch state until it has stopped, so the punch
  -- itself cuts the way up and burns worms on it, all jump long: PX adds no cut.
  --
  -- The frames are the worm's own: under Bullet Time (worm.time_scale) a world
  -- frame is 2 or 3 of them, and the timeline steps that many (own_time).
  local own_time = require("wf-lib/own_time")
  local jumps = {}   -- worm id -> frames since the punch
  local winding = {} -- worm id -> frames since fire was pressed
  -- A wind-up never takes this long; give up rather than fire late.
  local WIND_UP_MAX = 100
  -- Ready/charging, the firing sequence, then the native punch. A hit, fall,
  -- freeze or other loss of control must not become a delayed Fire Jump.
  local WIND_UP_STATES = {
    [0x67] = true, [0x68] = true, [0x69] = true,
    [0x6A] = true, [0x6B] = true, [0x6C] = true,
  }

  local function fire_jump(worm, t)
    if t == 1 then
      worm.vy = -9
    elseif t == 30 then
      worm.vx = worm.facing * 4
    elseif t == 60 then
      worm.vy = worm.vy - 1
    end
    if t > 80 and t < 210 and worm.vy > 5 then
      worm.vy = 4
    end
  end

  wa.on.worm_message(function(worm, msg)
    if msg == wa.msg.FIRE_WEAPON then
      if worm.weapon == "px.fire_jump" and worm:ammo("px.fire_jump") ~= 0 then
        winding[worm.id] = 0
      end
      -- It doesn't eat the shot: WA's fire punch still runs.
      return
    end
    if msg ~= wa.msg.FRAME_FINISH then return end
    local id = worm.id
    if not (winding[id] or jumps[id]) then return end
    -- Once WA ends the punch, its collisions and knockback own the speed.
    -- Forget the timeline permanently; regaining control cannot resume it.
    if not worm.turn or worm.hp <= 0 or worm.taken
        or (winding[id] and not WIND_UP_STATES[worm.state_id])
        or (jumps[id] and worm.state ~= "punching") then
      winding[id], jumps[id] = nil, nil
      return
    end
    local n = own_time.frames(worm)
    if winding[id] then
      if worm.state == "punching" and worm.vy < 0 then
        winding[id], jumps[id] = nil, 0
      else
        local w = winding[id] + n
        winding[id] = w < WIND_UP_MAX and w or nil
      end
    end
    for _ = 1, n do
      if not jumps[id] then break end
      local t = jumps[id] + 1
      fire_jump(worm, t)
      jumps[id] = t < 211 and t or nil
    end
  end, { msgs = { wa.msg.FIRE_WEAPON, wa.msg.FRAME_FINISH } })
end

return weapon
