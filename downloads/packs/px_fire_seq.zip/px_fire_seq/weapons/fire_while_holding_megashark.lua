-- Hold-to-fire Megashark: the fixed Megashark on its own slot, firing the
-- inventory's ammo (20 at most) while Space is held.
-- The shot, homing, trail and blast are the same as `megashark.lua`; only the
-- burst length and the stop condition differ. See README.md for the source.

local seq = require("lib/fire_seq")
local sb = require("lib/px_sprite_builder")
local trail = require("wf-lib/effects/trail")
local targetting = require("lib/targetting_missiles")
local hold_art = require("lib/px_hold_art")

local M = {}

local function placed(ctx)
  local informed = false
  if type(ctx.weapons) == "table" then
    informed = true
    if ctx.weapons[ctx.id] ~= nil then return true end
  end
  if type(ctx.placed) == "table" then
    informed = true
    for _, weapon in ipairs(ctx.placed) do
      if weapon == ctx.id or (type(weapon) == "table" and weapon.id == ctx.id) then return true end
    end
  end
  return not informed
end

function M.install(ctx)
  if not placed(ctx) then
    wa.log("Megashark (hold): in no panel slot; nothing registered")
    return
  end

  local ID = ctx.id
  local ART = "sprites/megashark/"
  local SND = "sounds/megashark/"

  -- Register callbacks from install: `wa` does not exist at require time.
  trail.install()
  targetting.install()
  local target_group = targetting.group()

  -- PX's numbers.
  local MAX_BURST = 20    -- finite ammo and infinite ammo both stop here
  local SHOT_DELAY = 4    -- WA's fire interval for this record
  local SPEED = 15.5      -- missileSpeed
  local TURN = 0.53       -- homingStrength
  local ARM_DIST = 90     -- activation distance
  local COOLDOWN = 2      -- homingCooldown
  local SENSOR2 = 199900  -- sensorRadiusSqr
  local PER_TARGET = 4    -- bulletsPerTarget
  local LOW_AIM = 0.164   -- low-angle extra offset

  -- PX has no trail on this record; this is the request's long green streak.
  local TRAIL = { max = 26, every = 1, core_w = 5.0, glow_w = 10.0,
    r = 90, g = 255, b = 120 }

  local function current_worm()
    for _, w in ipairs(wa.worms.all()) do
      if w.turn then return w end
    end
  end

  -- Worms whose hold-burst this weapon started.
  local holding = {}
  wa.on.worm_message(function(worm)
    if not holding[worm.id] then return end
    -- Clear the flag when the base's own cancel check would also end it.
    if not worm.turn or worm.weapon ~= ID then
      holding[worm.id] = nil
      seq.cancel(worm)
      return
    end
    if not wa.world.keys().space then
      holding[worm.id] = nil
      seq.cancel(worm)
    end
  end, { msgs = { wa.msg.FRAME_FINISH } })

  -- PX's homing: arm after ARM_DIST, then steer toward the nearest visible
  -- enemy every COOLDOWN frames. PX caps four bullets on one worm.
  wa.on.missile_frame(function(m)
    if m.weapon ~= ID then return end
    local entry = targetting.get(m.id)
    if not entry then
      local owner = current_worm()
      entry = targetting.add(m, SPEED, TURN, nil, owner)
      if not entry then return end
      entry.sensor2 = SENSOR2
      entry.cooldown = COOLDOWN
      entry.no_target_cd = 7
      entry.arm_dist = ARM_DIST
      entry.armed = false
      entry.max_target = PER_TARGET
      entry.on_target = target_group
      if owner and not trail.has(m.id) then trail.add(m.id, owner, TRAIL) end
    end
    -- The shared targetting hook steers on the same post phase.
  end)

  -- Hide WA's missile and draw the bullet from a follower actor.
  sb.flight(ctx, {
    weapon = ID,
    sheet = ART .. "bullet",
    anim = "none",
    frame_fn = function() return 0 end,
    z = wa.depth.OBJECTS - 1,
    mirror = false,
  })

  -- PX's 90x90 gun cell, arms baked in. The engine draws the aiming frames;
  -- `px_hold_art` covers the two firing frames it drops.
  local hold = {
    weapon = ID,
    sheet = ART .. "hold",
    size = 90,
    keep_while_firing = false,
    -- Swing the gun down and shrink it over the worm's put-away.
    put_away = true,
    weap_rotation = 1.0,
    weap_radial_rotation = 1.0,
    weap_radius = 0.0,
  }

  local spec = {
    wep = "weps/megashark_wep.wep",
    panel_icon = ART .. "icon.png",
    sprites = { ART .. "bullet", ART .. "hold", trail.BEAM, trail.GLOW },
    params = { gpu_prefix = "sprites/" },
    worm_sprites = sb.PX_POSTURE,
    hold = hold,
    sounds = { SND .. "shot.wav" },

    on_fire = function(ev)
      local w = ev.worm
      -- Inventory count before the burst; WA's infinite is -1.
      local ammo = w:ammo(ID)
      if ammo == 0 then return end
      local shots = ammo < 0 and MAX_BURST or math.min(ammo, MAX_BURST)
      if shots < 1 then return end
      -- Keep WA's muzzle distance, but re-apply it with the current facing:
      -- PX does that on every shot, and a script can turn the worm mid-burst.
      local ox = math.abs(ev.x - w.x)
      local oy = ev.y - w.y
      -- Keep WA's launch speed when it is usable; the homing pulls to 15.5.
      local speed = math.sqrt(ev.vx * ev.vx + ev.vy * ev.vy)
      if speed < 1 then speed = SPEED end

      -- Live aim, as PX's rebuilt Desc is: 0 straight down, 1 straight up.
      local function dir(ww)
        local ang = (1 - ww.aim) * math.pi
        if ww.facing < 0 then ang = 2 * math.pi - ang end
        return wa.math.sin(ang), -wa.math.cos(ang)
      end

      local timer = seq.fire_seq_mis({
        weapon = ID,
        cancel_weapon = ID,
        -- The muzzle is inside the worm's collision circle; start clear of it.
        standoff = 12,
        owner = w,
        count = shots,
        delay = SHOT_DELAY,
        x = function(i, ww)
          -- PX's forward offset, plus the low-angle extra.
          local low = ww.aim < LOW_AIM and 2.0 or 0
          return ww.x + ww.facing * (ox + 1.3 + low)
        end,
        y = function(i, ww)
          return ww.y + oy - 3.0 - (ww.aim < LOW_AIM and 2.9 or 0)
        end,
        vx = function(i, ww)
          local dx = dir(ww)
          return dx * speed
        end,
        vy = function(i, ww)
          local _, dy = dir(ww)
          return dy * speed
        end,
        spread = { y = 0.7 },
        on_shot = function(i, ww)
          wa.sound.play(ww, SND .. "shot.wav")
        end,
        -- Every end reaches here with the shots that actually left. Write the
        -- absolute remainder, as Highlander does; adding would break infinite.
        on_done = function(ww, fired)
          holding[ww.id] = nil
          if ammo >= 0 then
            ww:ammo(ID, { set = math.max(0, ammo - (fired or 0)) })
          end
        end,
      })
      if timer then holding[w.id] = true end
    end,

    -- The blast is the record's; here we release the target and the trail.
    on_explode = function(ev)
      local id = ev.missile
      if not id then return end
      targetting.remove(id)
      trail.drop(id)
    end,
  }
  spec.handling = { ends_turn = true }
  spec.fires = { subtype = 4 } -- PX's record has no pose; 4 is the minigun's
  hold_art.add(hold)
  wa.weapons.replace(spec)
end

return M
